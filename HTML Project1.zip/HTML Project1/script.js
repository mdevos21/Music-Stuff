var audio = document.getElementById("myAudio");

function playAudio() {
    audio.play();
}

function checkAndPlay(event) {
    event.preventDefault(); // Prevent form submission

    var userInput = document.getElementById("textInput").value.toLowerCase();
    if (userInput === "mathis") {
        playAudio();
    } else {
        alert("Type 'Mathis' to play the audio.");
    }
}
